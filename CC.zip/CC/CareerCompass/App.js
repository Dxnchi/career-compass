import React, { useState, useMemo } from 'react';
import { StyleSheet, View, SafeAreaView, StatusBar } from 'react-native';

import {
  INITIAL_USER_PROFILE,
  INITIAL_SUBJECT_GRADES,
  INITIAL_PROGRAM_MATCHES,
  DEADLINES_DATA,
  calculateAPS,
} from './src/data/dataStore';

// Components & Modals
import Navigation from './src/components/Navigation';
import ApplicationModal from './src/components/ApplicationModal';

// Screens
import WelcomeScreen from './src/screens/WelcomeScreen';
import HomeScreen from './src/screens/HomeScreen';
import ScanScreen from './src/screens/ScanScreen';
import ConfirmGradesScreen from './src/screens/ConfirmGradesScreen';
import MatchesScreen from './src/screens/MatchesScreen';
import ProgramDetailScreen from './src/screens/ProgramDetailScreen';
import ExploreScreen from './src/screens/ExploreScreen';
import NotificationsScreen from './src/screens/NotificationsScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import SettingsScreen from './src/screens/SettingsScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('welcome');
  const [user, setUser] = useState(INITIAL_USER_PROFILE);
  const [grades, setGrades] = useState(INITIAL_SUBJECT_GRADES);
  const [matches, setMatches] = useState(INITIAL_PROGRAM_MATCHES);
  const [selectedProgram, setSelectedProgram] = useState(INITIAL_PROGRAM_MATCHES[0]);
  const [appModalVisible, setAppModalVisible] = useState(false);

  const currentAps = useMemo(() => calculateAPS(grades), [grades]);

  const handleScanDone = (scannedGrades) => {
    setGrades(scannedGrades);
    setCurrentScreen('confirm_grades');
  };

  const handleGradesConfirmed = (finalGrades) => {
    setGrades(finalGrades);
    setCurrentScreen('matches');
  };

  const showBottomNav =
    currentScreen !== 'welcome' &&
    currentScreen !== 'scan' &&
    currentScreen !== 'confirm_grades';

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0a0a0a" />
      <View style={styles.body}>
        {currentScreen === 'welcome' && (
          <WelcomeScreen
            user={user}
            onGetStarted={() => setCurrentScreen('home')}
            onOpenTerms={() => setCurrentScreen('settings')}
          />
        )}
        {currentScreen === 'home' && (
          <HomeScreen
            user={user}
            matches={matches}
            deadlines={DEADLINES_DATA}
            currentAps={currentAps}
            onNavigate={(screen) => setCurrentScreen(screen)}
            onSelectProgram={(prog) => {
              setSelectedProgram(prog);
              setCurrentScreen('program_detail');
            }}
          />
        )}
        {currentScreen === 'scan' && (
          <ScanScreen
            onCancel={() => setCurrentScreen('home')}
            onScanComplete={handleScanDone}
          />
        )}
        {currentScreen === 'confirm_grades' && (
          <ConfirmGradesScreen
            initialGrades={grades}
            onBack={() => setCurrentScreen('scan')}
            onConfirm={handleGradesConfirmed}
          />
        )}
        {currentScreen === 'matches' && (
          <MatchesScreen
            matches={matches}
            onBack={() => setCurrentScreen('home')}
            onSelectProgram={(prog) => {
              setSelectedProgram(prog);
              setCurrentScreen('program_detail');
            }}
          />
        )}
        {currentScreen === 'program_detail' && (
          <ProgramDetailScreen
            program={selectedProgram}
            onBack={() => setCurrentScreen('matches')}
            onStartApplication={() => setAppModalVisible(true)}
          />
        )}
        {currentScreen === 'explore' && <ExploreScreen />}
        {currentScreen === 'notifications' && (
          <NotificationsScreen onBack={() => setCurrentScreen('home')} />
        )}
        {currentScreen === 'profile' && (
          <ProfileScreen
            user={user}
            currentAps={currentAps}
            onNavigateSettings={() => setCurrentScreen('settings')}
          />
        )}
        {currentScreen === 'settings' && (
          <SettingsScreen
            user={user}
            onBack={() => setCurrentScreen('profile')}
            onSaveUser={setUser}
            onLogout={() => setCurrentScreen('welcome')}
          />
        )}
      </View>

      {showBottomNav && (
        <Navigation
          currentScreen={currentScreen}
          onNavigate={(screen) => setCurrentScreen(screen)}
        />
      )}

      <ApplicationModal
        visible={appModalVisible}
        program={selectedProgram}
        onClose={() => setAppModalVisible(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a0a0a' },
  body: { flex: 1 },
});