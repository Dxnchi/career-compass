import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';

export default function NotificationsScreen({ deadlines }) {
  return (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.heading}>Notifications</Text>
      <Text style={styles.subtitle}>Important application and funding dates.</Text>
      {deadlines.map((deadline) => (
        <View key={deadline.id} style={styles.card}>
          <View style={styles.date}>
            <Text style={styles.month}>{deadline.month}</Text>
            <Text style={styles.day}>{deadline.day}</Text>
          </View>
          <View style={styles.copy}>
            <Text style={styles.title}>{deadline.title}</Text>
            <Text style={styles.description}>{deadline.subtitle}</Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  heading: { color: '#f4f4f5', fontSize: 24, fontWeight: 'bold' },
  subtitle: { color: '#a1a1aa', fontSize: 13, marginBottom: 20, marginTop: 6 },
  card: { alignItems: 'center', backgroundColor: '#141416', borderColor: '#27272a', borderRadius: 14, borderWidth: 1, flexDirection: 'row', gap: 14, marginBottom: 12, padding: 14 },
  date: { alignItems: 'center', backgroundColor: '#27272a', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, width: 52 },
  month: { color: '#f87171', fontSize: 10, fontWeight: 'bold' },
  day: { color: '#f4f4f5', fontSize: 17, fontWeight: 'bold', marginTop: 2 },
  copy: { flex: 1 },
  title: { color: '#f4f4f5', fontSize: 14, fontWeight: '600' },
  description: { color: '#a1a1aa', fontSize: 12, lineHeight: 18, marginTop: 4 },
});
