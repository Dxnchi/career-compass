import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { Compass, ArrowRight } from 'lucide-react-native';

export default function WelcomeScreen({ user, onGetStarted, onOpenTerms, onNavigate }) {
  // Safe extraction with default fallback name
  const firstName = user?.name ? user.name.split(' ')[0] : 'there';
  const handleProceed = onGetStarted || (() => onNavigate?.('home'));

  return (
    <View style={styles.container}>
      <View style={styles.heroBox}>
        <View style={styles.logoBadge}>
          <Compass color="#3b82f6" size={54} />
        </View>
        <Text style={styles.title}>Welcome to Career Compass</Text>
        <Text style={styles.subtitle}>
          Hi {firstName}, find study programs that match your results and career goals.
        </Text>
      </View>

      <View style={styles.actionBox}>
        <TouchableOpacity style={styles.primaryButton} onPress={handleProceed}>
          <Text style={styles.primaryButtonText}>Get Started</Text>
          <ArrowRight color="#ffffff" size={18} />
        </TouchableOpacity>

        {onOpenTerms && (
          <TouchableOpacity onPress={onOpenTerms}>
            <Text style={styles.termsText}>
              Protected under POPIA • Terms & Conditions
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
    justifyContent: 'space-between',
    padding: 24,
  },
  heroBox: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoBadge: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: '#111827',
    borderWidth: 2,
    borderColor: '#1e3a8a',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  title: {
    color: '#f4f4f5',
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subtitle: {
    color: '#a1a1aa',
    fontSize: 15,
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 22,
    maxWidth: 290,
  },
  actionBox: {
    gap: 16,
    marginBottom: 20,
  },
  primaryButton: {
    backgroundColor: '#2563eb',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 16,
    borderRadius: 14,
    gap: 8,
  },
  primaryButtonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  termsText: {
    color: '#71717a',
    textAlign: 'center',
    fontSize: 12,
  },
});