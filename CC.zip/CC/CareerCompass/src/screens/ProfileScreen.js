import React from 'react';
import { Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

export default function ProfileScreen({ user, aps, onNavigate }) {
  return (
    <ScrollView contentContainerStyle={styles.content}>
      <Text style={styles.heading}>Profile</Text>
      <View style={styles.profileCard}>
        <Image source={{ uri: user.avatar }} style={styles.avatar} />
        <Text style={styles.name}>{user.name}</Text>
        <Text style={styles.muted}>{user.grade}</Text>
        <Text style={styles.muted}>{user.school}</Text>
      </View>
      <View style={styles.infoCard}>
        <Info label="Email" value={user.email} />
        <Info label="Phone" value={user.phone} />
        <Info label="Career interests" value={user.targetCareer} />
        <Info label="Preferred provinces" value={user.preferredProvince} />
        <Info label="Current APS" value={`${aps} points`} />
      </View>
      <TouchableOpacity style={styles.rowButton} onPress={() => onNavigate('settings')}>
        <Text style={styles.rowText}>Settings</Text>
        <Text style={styles.arrow}>›</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.rowButton} onPress={() => onNavigate('welcome')}>
        <Text style={styles.rowText}>Welcome screen</Text>
        <Text style={styles.arrow}>›</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function Info({ label, value }) {
  return (
    <View style={styles.infoRow}>
      <Text style={styles.label}>{label}</Text>
      <Text style={styles.value}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 32 },
  heading: { color: '#f4f4f5', fontSize: 24, fontWeight: 'bold', marginBottom: 18 },
  profileCard: { alignItems: 'center', backgroundColor: '#141416', borderColor: '#27272a', borderRadius: 16, borderWidth: 1, padding: 20 },
  avatar: { borderRadius: 36, height: 72, width: 72 },
  name: { color: '#f4f4f5', fontSize: 18, fontWeight: 'bold', marginTop: 12 },
  muted: { color: '#a1a1aa', fontSize: 12, marginTop: 5, textAlign: 'center' },
  infoCard: { backgroundColor: '#141416', borderColor: '#27272a', borderRadius: 16, borderWidth: 1, marginTop: 14, paddingHorizontal: 14 },
  infoRow: { borderBottomColor: '#27272a', borderBottomWidth: 1, paddingVertical: 12 },
  label: { color: '#71717a', fontSize: 11 },
  value: { color: '#e4e4e7', fontSize: 13, marginTop: 4 },
  rowButton: { alignItems: 'center', backgroundColor: '#141416', borderColor: '#27272a', borderRadius: 12, borderWidth: 1, flexDirection: 'row', justifyContent: 'space-between', marginTop: 12, padding: 15 },
  rowText: { color: '#f4f4f5', fontSize: 14, fontWeight: '600' },
  arrow: { color: '#71717a', fontSize: 22 },
});
