import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Bell, Compass, Home, Scan, UserRound } from 'lucide-react-native';

const TABS = [
  { id: 'home', label: 'Home', Icon: Home },
  { id: 'explore', label: 'Explore', Icon: Compass },
  { id: 'scan', label: 'Scan', Icon: Scan },
  { id: 'notifications', label: 'Alerts', Icon: Bell },
  { id: 'profile', label: 'Profile', Icon: UserRound },
];

export default function Navigation({ currentScreen, onNavigate }) {
  return (
    <View style={styles.tabBar}>
      {TABS.map(({ id, label, Icon }) => {
        const active = currentScreen === id || (id === 'explore' && currentScreen === 'matches');
        return (
          <TouchableOpacity
            key={id}
            accessibilityRole="button"
            accessibilityState={{ selected: active }}
            style={styles.tabItem}
            onPress={() => onNavigate(id)}
          >
            <Icon color={active ? '#3b82f6' : '#71717a'} size={21} />
            <Text style={[styles.tabLabel, active && styles.tabLabelActive]}>{label}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row',
    backgroundColor: '#0d0d0f',
    borderTopWidth: 1,
    borderTopColor: '#27272a',
    paddingVertical: 8,
    justifyContent: 'space-around',
  },
  tabItem: { alignItems: 'center', flex: 1 },
  tabLabel: { color: '#71717a', fontSize: 10, marginTop: 3 },
  tabLabelActive: { color: '#3b82f6', fontWeight: 'bold' },
});
